using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using ATAS.Indicators;
using OFT.Rendering.Context;
using OFT.Rendering.Tools;
using Color = System.Drawing.Color;

namespace FootprintSignals
{
    public enum HorsZone { Attenuer, Masquer, Normal }

    [DisplayName("Footprint Signals (Mind xtrade)")]
    public class FootprintSignalsIndicator : Indicator
    {
        const string Version = "1.11";
        readonly FpSettings S = new();
        readonly ConcurrentDictionary<int, Signal[]> _signals = new();
        readonly Dictionary<int, FpBar> _cache = new();
        readonly Dictionary<int, RenderFont> _fonts = new();

        public FootprintSignalsIndicator() : base(true)
        {
            DenyToChangePanel = true;
            EnableCustomDrawing = true;
            SubscribeToDrawingEvents(DrawingLayouts.Final);
            DataSeries[0].IsHidden = true;
        }

        void Recalc() { RecalculateValues(); }

        // ================= AFFICHAGE =================
        int _fontSize = 7;
        [Display(Name = "Taille du texte (minimum)", GroupName = "0. Affichage", Order = 1)]
        [Range(6, 24)]
        public int TextSizeMin { get => _fontSize; set { _fontSize = Math.Max(6, value); RedrawChart(); } }

        [Display(Name = "Taille auto selon le zoom", GroupName = "0. Affichage", Order = 2, Description = "Le texte grossit quand les lignes du footprint grandissent")]
        public bool AutoFontSize { get; set; } = true;

        [Display(Name = "Taille max (mode auto)", GroupName = "0. Affichage", Order = 3)]
        [Range(6, 30)]
        public int TextSizeMax { get; set; } = 7;

        [Display(Name = "Texte en gras", GroupName = "0. Affichage", Order = 4)]
        public bool TextBold { get; set; } = false;

        [Display(Name = "Couleur haussière", GroupName = "0. Affichage", Order = 5)]
        public Color BullColor { get; set; } = Color.FromArgb(255, 70, 210, 140);

        [Display(Name = "Couleur baissière", GroupName = "0. Affichage", Order = 6)]
        public Color BearColor { get; set; } = Color.FromArgb(255, 255, 95, 95);

        [Display(Name = "Fond derrière le texte", GroupName = "0. Affichage", Order = 7)]
        public bool ShowBackground { get; set; } = true;

        [Display(Name = "Couleur du fond", GroupName = "0. Affichage", Order = 8)]
        public Color BackgroundColor { get; set; } = Color.FromArgb(230, 14, 18, 28);

        [Display(Name = "Signaux baissiers au-dessus de la barre", GroupName = "0. Affichage", Order = 9)]
        public bool BearAbove { get; set; } = false;

        [Display(Name = "Espace sous la barre (px)", GroupName = "0. Affichage", Order = 10)]
        [Range(0, 100)]
        public int OffsetPx { get; set; } = 4;

        [Display(Name = "Masquer si barres plus étroites que (px)", GroupName = "0. Affichage", Order = 11)]
        [Range(0, 100)]
        public int MinBarWidthPx { get; set; } = 6;

        [Display(Name = "Afficher le sens (+ / -)", GroupName = "0. Affichage", Order = 12)]
        public bool ShowSign { get; set; } = true;

        RenderFont FontFor(int size)
        {
            int key = size * (TextBold ? -1 : 1);
            if (!_fonts.TryGetValue(key, out var f))
            {
                f = null;
                if (TextBold)
                {
                    try
                    {
                        // constructeur (string, float, FontStyle) appelé par réflexion : FontStyle.Bold = 1
                        var ctor = typeof(RenderFont).GetConstructors().FirstOrDefault(k => { var ps = k.GetParameters(); return ps.Length == 3 && ps[2].ParameterType.IsEnum && ps[2].ParameterType.Name == "FontStyle"; });
                        if (ctor != null) f = (RenderFont)ctor.Invoke(new object[] { "Arial", (float)size, Enum.ToObject(ctor.GetParameters()[2].ParameterType, 1) });
                    }
                    catch { f = null; }
                }
                f ??= new RenderFont("Arial", size);
                _fonts[key] = f;
            }
            return f;
        }

        // ================= FILTRES =================
        const string GF = "00. FILTRES (lire en premier)";
        [Display(Name = "Delta significatif (contrats)", GroupName = GF, Order = 1, Description = "Seuil commun à ABS, DIV DELTA, TRANS PLUS, SURGE, NOBUYER/NOSELLER, FLIP. ES : 150-200. DAX : beaucoup plus bas.")]
        public decimal SigDelta { get => S.SigDelta; set { S.SigDelta = value; Recalc(); } }

        [Display(Name = "Zones : activer", GroupName = GF, Order = 2, Description = "Zones = canaux horizontaux et lignes horizontales dessinés sur le graphique + niveaux tapés ci-dessous.")]
        public bool ZonesActive { get; set; } = false;
        [Display(Name = "Zones : signaux hors zone", GroupName = GF, Order = 3, Description = "Attenuer = affichés en transparence (on voit les excès sans être distrait) ; Masquer ; Normal")]
        public HorsZone OutOfZone { get; set; } = HorsZone.Attenuer;
        [Display(Name = "Zones : opacité hors zone (%)", GroupName = GF, Order = 3)]
        [Range(5, 100)]
        public int OutOfZoneOpacity { get; set; } = 30;
        [Display(Name = "Zones : lire mes canaux et lignes horizontales", GroupName = GF, Order = 3, Description = "Les rectangles ne sont pas lisibles par un indicateur ATAS : dessiner les zones en « canal horizontal ».")]
        public bool ZonesFromDrawings { get; set; } = true;
        [Display(Name = "Zones : niveaux tapés (ex. 6815.25 ; 6830-6834)", GroupName = GF, Order = 4)]
        public string ManualLevels { get => _manualText; set { _manualText = value ?? ""; _manual = Zones.Parse(_manualText); RedrawChart(); } }
        string _manualText = "";
        List<(decimal Lo, decimal Hi)> _manual = new();
        [Display(Name = "Zones : tolérance (ticks)", GroupName = GF, Order = 5)]
        [Range(0, 100)]
        public int ZoneTolTicks { get; set; } = 4;

        [Display(Name = "Confluence : activer", GroupName = GF, Order = 6, Description = "Défaut : au moins 2 signaux du même sens dont 1 majeur. 1 = chaque majeur seul s'affiche (beaucoup plus de signaux) ; 3 = seulement les situations très chargées.")]
        public bool ConfluenceActive { get; set; } = true;
        [Display(Name = "Confluence : nombre minimum de signaux", GroupName = GF, Order = 7)]
        [Range(1, 6)]
        public int ConfluenceMinimum { get; set; } = 2;
        [Display(Name = "Confluence : exiger au moins un signal majeur", GroupName = GF, Order = 7, Description = "Majeurs : TRANS PLUS, FLIP, ABS, NOBUYER/NOSELLER, TAIL, SURGE. Mineurs (renfort seulement) : DIV DELTA, DIV VOL, IMB, STK, VOL SEQ, TRANS")]
        public bool ConfluenceNeedMajor { get; set; } = true;
        [Display(Name = "Confluence : barres précédentes prises en compte", GroupName = GF, Order = 8, Description = "La barre du signal + N barres AVANT. Aucun retard d'affichage.")]
        [Range(0, 3)]
        public int ConfluenceBarsBack { get; set; } = 1;
        [Display(Name = "Confluence : inclure aussi les barres suivantes (retarde l'affichage)", GroupName = GF, Order = 9, Description = "Ancien comportement : un signal peut attendre la clôture de la barre suivante pour s'afficher")]
        public bool ConfluenceLookAhead { get; set; } = false;

        // ================= 1. ABSORPTION =================
        const string G1 = "1. ABSORPTION";
        [Display(Name = "Activer", GroupName = G1, Order = 10, Description = "Barre à forte agression, puis la barre suivante ne refait pas d'extrême dans ce sens. Étiquette posée à la clôture de la barre suivante.")]
        public bool AbsOn { get => S.AbsOn; set { S.AbsOn = value; Recalc(); } }
        [Display(Name = "Delta minimum en % du volume de la barre", GroupName = G1, Order = 12)]
        public decimal AbsMinPct { get => S.AbsMinPct; set { S.AbsMinPct = value; Recalc(); } }
        [Display(Name = "Tolérance sur l'extrême (ticks)", GroupName = G1, Order = 13, Description = "0 = la barre suivante ne doit pas dépasser du tout l'extrême")]
        public decimal AbsToleranceTicks { get => S.AbsToleranceTicks; set { S.AbsToleranceTicks = value; Recalc(); } }

        // ================= 2. TRANSITION DU DELTA =================
        const string G2 = "2. TRANSITION DU DELTA";
        [Display(Name = "Activer", GroupName = G2, Order = 20, Description = "Réf. +181 / barre 1 +45 (s'essouffle) / barre 2 -78 (TRANS) / barre 3 -144 (TRANS PLUS)")]
        public bool TrnOn { get => S.TrnOn; set { S.TrnOn = value; Recalc(); } }
        [Display(Name = "Afficher l'alerte TRANS (barre 2)", GroupName = G2, Order = 21)]
        public bool TrnShowEarly { get => S.TrnShowEarly; set { S.TrnShowEarly = value; Recalc(); } }

        // ================= 3. DIVERGENCES =================
        const string G3 = "3. DIVERGENCES";
        [Display(Name = "DIV DELTA : activer", GroupName = G3, Order = 30, Description = "Nouveau bas avec delta positif, ou nouveau haut avec delta négatif (module 7)")]
        public bool DivOn { get => S.DivOn; set { S.DivOn = value; Recalc(); } }
        [Display(Name = "DIV DELTA : delta minimum (contrats)", GroupName = G3, Order = 31, Description = "Seuil propre à la divergence (ES : au moins 250)")]
        public decimal DivMinDelta { get => S.DivMinDelta; set { S.DivMinDelta = value; Recalc(); } }
        [Display(Name = "DIV DELTA : signal fort « ! » à partir de", GroupName = G3, Order = 31, Description = "0 = jamais")]
        public decimal DivStrong { get => S.DivStrong; set { S.DivStrong = value; Recalc(); } }
        [Display(Name = "DIV VOL : activer", GroupName = G3, Order = 32, Description = "Nouveau bas avec volume en hausse, ou nouveau haut avec volume en baisse (module 7)")]
        public bool DivVolActive { get => S.DivVOn; set { S.DivVOn = value; Recalc(); } }

        // ================= 4. NO BUYER / NO SELLER =================
        const string G4 = "4. NO BUYER / NO SELLER";
        [Display(Name = "Activer", GroupName = G4, Order = 40, Description = "NOBUYER : Max Delta à 0 ou proche ; NOSELLER : Min Delta à 0 ou proche")]
        public bool NbOn { get => S.NbOn; set { S.NbOn = value; Recalc(); } }
        [Display(Name = "Delta minimum en % du volume", GroupName = G4, Order = 42, Description = "Captures de Jo : -7 (-28 %) et -655 (-27 %) marqués, -193 (-4,8 %) non")]
        public decimal NbMinPct { get => S.NbMinPct; set { S.NbMinPct = value; Recalc(); } }
        [Display(Name = "« Ou proche de 0 » : autre camp max (% du delta)", GroupName = G4, Order = 43, Description = "0 = règle stricte de l indicateur de Jo (+405 avec Min Delta -1 non marqué). Ex. 1 : delta -2000 avec Max Delta +15 devient NOBUYER")]
        public decimal NbNearZeroPct { get => S.NbNearZeroPct; set { S.NbNearZeroPct = value; Recalc(); } }

        // ================= 5. SURGE / VOLUME SÉQUENTIEL =================
        const string G5 = "5. SURGE / VOLUME SEQUENTIEL";
        [Display(Name = "SURGE : activer", GroupName = G5, Order = 50)]
        public bool SrgOn { get => S.SrgOn; set { S.SrgOn = value; Recalc(); } }
        [Display(Name = "SURGE : nombre de barres croissantes", GroupName = G5, Order = 51)]
        [Range(2, 10)]
        public int SrgBars { get => S.SrgBars; set { S.SrgBars = value; Recalc(); } }
        [Display(Name = "SURGE : exiger une barre de départ opposée", GroupName = G5, Order = 52)]
        public bool SrgNeedOppositeStart { get => S.SrgNeedOppositeStart; set { S.SrgNeedOppositeStart = value; Recalc(); } }
        [Display(Name = "VOL SEQ : activer", GroupName = G5, Order = 54, Description = "N croissances consécutives du delta (live coaching : 5)")]
        public bool VseqOn { get => S.VseqOn; set { S.VseqOn = value; Recalc(); } }
        [Display(Name = "VOL SEQ : nombre de croissances", GroupName = G5, Order = 55)]
        [Range(2, 15)]
        public int VseqCount { get => S.VseqCount; set { S.VseqCount = value; Recalc(); } }

        // ================= 6. DELTA TAIL =================
        const string G6 = "6. DELTA TAIL";
        [Display(Name = "Activer", GroupName = G6, Order = 60, Description = "Tail vendeur : deltas positifs successifs au sommet, reste de la barre négatif, barre descendante (vidéo de Jo)")]
        public bool TailOn { get => S.TailOn; set { S.TailOn = value; Recalc(); } }
        [Display(Name = "Taille max de la queue (niveaux)", GroupName = G6, Order = 61)]
        [Range(1, 10)]
        public int TailMaxTicks { get => S.TailMaxTicks; set { S.TailMaxTicks = value; Recalc(); } }
        [Display(Name = "Delta minimum de la queue (abs)", GroupName = G6, Order = 62)]
        public decimal TailMinDelta { get => S.TailMinDelta; set { S.TailMinDelta = value; Recalc(); } }
        [Display(Name = "Delta minimum du reste de la barre (abs)", GroupName = G6, Order = 63)]
        public decimal TailRestMinDelta { get => S.TailRestMinDelta; set { S.TailRestMinDelta = value; Recalc(); } }
        [Display(Name = "Exiger une barre qui clôture dans l'autre sens", GroupName = G6, Order = 64)]
        public bool TailNeedReverseClose { get => S.TailNeedReverseClose; set { S.TailNeedReverseClose = value; Recalc(); } }

        // ================= 7. OPTIONS (hors liste de Jo) =================
        // ================= 8. REVERSAL / FADING =================
        const string G8 = "8. DELTA REVERSAL / FADING MOMENTUM";
        [Display(Name = "REVERSAL : activer", GroupName = G8, Order = 90, Description = "Gros delta qui avale le delta opposé de la (des) barre(s) précédente(s) en cassant son niveau (session 15 : « le plus puissant des signaux »)")]
        public bool RevOn { get => S.RevOn; set { S.RevOn = value; Recalc(); } }
        [Display(Name = "REVERSAL : barres à avaler (1 ou 2)", GroupName = G8, Order = 91, Description = "Jo préfère 2 : « il n'y a pas de concession »")]
        [Range(1, 3)]
        public int RevBars { get => S.RevBars; set { S.RevBars = value; Recalc(); } }
        [Display(Name = "FADING : activer", GroupName = G8, Order = 92, Description = "Delta qui s'épuise sur 3 barres (284 / 246 / 26). À ne jouer que dans le sens de la narration (signal mineur)")]
        public bool FadeOn { get => S.FadeOn; set { S.FadeOn = value; Recalc(); } }
        [Display(Name = "FADING : 3e barre au plus X % de la 1re", GroupName = G8, Order = 93)]
        [Range(1, 100)]
        public decimal FadeEndPct { get => S.FadeEndPct; set { S.FadeEndPct = value; Recalc(); } }

        // ================= 9. STOPS =================
        const string G9 = "9. STOPS";
        [Display(Name = "Afficher le stop des signaux majeurs", GroupName = G9, Order = 100, Description = "1 tick au-delà de la structure du signal (transition : bougie centrale), règle de Jo « un tick, jamais deux »")]
        public bool ShowStops { get; set; } = true;
        [Display(Name = "Afficher la distance du stop (ticks)", GroupName = G9, Order = 101)]
        public bool ShowStopTicks { get; set; } = true;
        [Display(Name = "Longueur du trait (en barres)", GroupName = G9, Order = 102)]
        [Range(1, 10)]
        public int StopLineBars { get; set; } = 3;

        const string G7 = "7. FLIP / IMBALANCE / STACK";
        [Display(Name = "FLIP : activer", GroupName = G7, Order = 70, Description = "Barre sans acheteur (Max Delta ~0, clôture près du Min Delta) puis barre sans vendeur (Min Delta ~0, clôture près du Max Delta)")]
        public bool FlipOn { get => S.FlipOn; set { S.FlipOn = value; Recalc(); } }
        [Display(Name = "FLIP : incursion max de l'autre camp (% du delta)", GroupName = G7, Order = 71, Description = "« 0 de max delta ou proche »")]
        public decimal FlipNearZeroPct { get => S.FlipNearZeroPct; set { S.FlipNearZeroPct = value; Recalc(); } }
        [Display(Name = "FLIP : clôture à au moins X % du delta extrême", GroupName = G7, Order = 72, Description = "« se ferme près de sa valeur max delta »")]
        public decimal FlipCloseNearPct { get => S.FlipCloseNearPct; set { S.FlipCloseNearPct = value; Recalc(); } }
        [Display(Name = "FLIP : delta minimum en % du volume", GroupName = G7, Order = 73)]
        public decimal FlipMinPct { get => S.FlipMinPct; set { S.FlipMinPct = value; Recalc(); } }
        [Display(Name = "FLIP : autoriser une barre intermédiaire", GroupName = G7, Order = 74)]
        public bool FlipAllowMiddleBar { get => S.FlipAllowMiddleBar; set { S.FlipAllowMiddleBar = value; Recalc(); } }
        [Display(Name = "IMB : activer", GroupName = G7, Order = 74)]
        public bool ImbActive { get => S.ImbOn; set { S.ImbOn = value; Recalc(); } }
        [Display(Name = "IMB : ratio diagonal (%)", GroupName = G7, Order = 75)]
        public decimal ImbRatioPct { get => S.ImbRatioPct; set { S.ImbRatioPct = value; Recalc(); } }
        [Display(Name = "IMB : volume minimum du côté dominant", GroupName = G7, Order = 76)]
        public decimal ImbMinVolume { get => S.ImbMinVolume; set { S.ImbMinVolume = value; Recalc(); } }
        [Display(Name = "IMB : niveau max depuis l'extrême (2 = 2e ligne)", GroupName = G7, Order = 77)]
        [Range(2, 5)]
        public int ImbMaxLevel { get => S.ImbMaxLevel; set { S.ImbMaxLevel = value; Recalc(); } }
        [Display(Name = "IMB : exiger un nouvel extrême", GroupName = G7, Order = 78)]
        public bool ImbNeedNewExtreme { get => S.ImbNeedNewExtreme; set { S.ImbNeedNewExtreme = value; Recalc(); } }
        [Display(Name = "IMB : le POC ne doit pas gêner", GroupName = G7, Order = 78, Description = "Achat : POC de la barre au niveau de l'imbalance ou en dessous (idéalement en bas de barre)")]
        public bool ImbPocCheck { get => S.ImbPocCheck; set { S.ImbPocCheck = value; Recalc(); } }
        [Display(Name = "STACK : activer", GroupName = G7, Order = 79)]
        public bool StkActive { get => S.StkOn; set { S.StkOn = value; Recalc(); } }
        [Display(Name = "STACK : imbalances consécutives minimum", GroupName = G7, Order = 80)]
        [Range(2, 10)]
        public int StkMinCount { get => S.StkMinCount; set { S.StkMinCount = value; Recalc(); } }

        // ================= CALCUL =================
        protected override void OnCalculate(int bar, decimal value)
        {
            if (bar == 0) { _signals.Clear(); _cache.Clear(); }
            // On n'évalue que les barres clôturées : à l'ouverture de 'bar', 'bar-1' est terminée.
            int b = bar - 1;
            if (b < 0 || _signals.ContainsKey(b)) return;
            decimal tick = InstrumentInfo?.TickSize ?? 0.25m;
            if (tick <= 0) tick = 0.25m;
            try
            {
                var sigs = SignalEngine.Evaluate(GetBar, b, S, tick);
                _signals[b] = sigs.Where(x => x.Offset == 0).ToArray();
                var back = sigs.Where(x => x.Offset == -1).ToArray();
                if (back.Length > 0 && b >= 1)
                    _signals[b - 1] = (_signals.TryGetValue(b - 1, out var old) ? old : Array.Empty<Signal>()).Concat(back).ToArray();
            }
            catch { _signals[b] = Array.Empty<Signal>(); }
            // libère le cache des vieilles barres
            if (_cache.Count > 64) foreach (var k in _cache.Keys.Where(k => k < b - 20).ToList()) _cache.Remove(k);
        }

        FpBar GetBar(int i)
        {
            if (i < 0 || i >= CurrentBar) return null;
            if (_cache.TryGetValue(i, out var fb)) return fb;
            var c = GetCandle(i);
            if (c == null) return null;
            fb = new FpBar { Open = c.Open, High = c.High, Low = c.Low, Close = c.Close, Delta = c.Delta, Volume = c.Volume, MaxDelta = c.MaxDelta, MinDelta = c.MinDelta };
            var levels = c.GetAllPriceLevels();
            if (levels != null)
                foreach (var lv in levels)
                    if (lv != null) fb.Levels[lv.Price] = (lv.Bid, lv.Ask);
            _cache[i] = fb;
            return fb;
        }

        // nombre de patterns distincts du même sens sur la barre et ses voisines
        bool ConfluenceOk(int bar, int dir)
        {
            var codes = new HashSet<string>(); bool major = false;
            int fwd = ConfluenceLookAhead ? ConfluenceBarsBack : 0;   // par défaut : jamais attendre les barres suivantes
            for (int i = bar - ConfluenceBarsBack; i <= bar + fwd; i++)
                if (_signals.TryGetValue(i, out var ss))
                    foreach (var x in ss) if (x.Dir == dir) { codes.Add(x.Code); if (SignalEngine.Major.Contains(x.Code)) major = true; }
            return codes.Count >= ConfluenceMinimum && (!ConfluenceNeedMajor || major);
        }

        // ================= RENDU =================
        protected override void OnRender(RenderContext context, DrawingLayouts layout)
        {
            if (ChartInfo == null) return;
            var cont = ChartInfo.PriceChartContainer;
            if (cont == null) return;

            decimal tick = InstrumentInfo?.TickSize ?? 0.25m;
            if (tick <= 0) tick = 0.25m;

            int first = Math.Max(0, cont.FirstVisibleBarNumber);
            int last = Math.Min(CurrentBar - 1, cont.LastVisibleBarNumber);
            int bw = (int)cont.BarsWidth;

            // zones : dessins (canaux / lignes horizontales) + niveaux tapés
            var zones = new List<(decimal Lo, decimal Hi)>(_manual);
            if (ZonesFromDrawings)
            {
                try
                {
                    var dl = ChartInfo.DrawingObjectsListInfo;
                    if (dl != null)
                    {
                        if (dl.HorizontalChannels != null)
                            foreach (var ch in dl.HorizontalChannels)
                                if (ch != null) zones.Add((Math.Min(ch.FirstPrice, ch.SecondPrice), Math.Max(ch.FirstPrice, ch.SecondPrice)));
                        if (dl.HorizontalLines != null)
                            foreach (var hl in dl.HorizontalLines)
                                if (hl != null) zones.Add((hl.Price, hl.Price));
                    }
                }
                catch { }
            }
            bool zonesActive = ZonesActive && zones.Count > 0;

            if (bw >= MinBarWidthPx)
            {
                for (int bar = first; bar <= last; bar++)
                {
                    if (!_signals.TryGetValue(bar, out var sigs) || sigs.Length == 0) continue;
                    var c = GetCandle(bar);
                    if (c == null) continue;
                    bool dim = false;
                    if (zonesActive && !Zones.Touches(c.Low, c.High, zones, ZoneTolTicks * tick))
                    {
                        if (OutOfZone == HorsZone.Masquer) continue;
                        dim = OutOfZone == HorsZone.Attenuer;
                    }
                    if (ConfluenceActive) sigs = sigs.Where(sg => ConfluenceOk(bar, sg.Dir)).ToArray();
                    if (sigs.Length == 0) continue;

                    // Hauteur d'une ligne de prix à l'écran
                    int rowH = Math.Abs(cont.GetYByPrice(c.Low, true) - cont.GetYByPrice(c.Low + tick, true));
                    if (rowH <= 0) rowH = 10;

                    int size = TextSizeMin;
                    if (AutoFontSize) size = Math.Max(TextSizeMin, Math.Min(TextSizeMax, (int)Math.Round(rowH * 0.8)));
                    var font = FontFor(size);

                    // Bas de la barre = début de la ligne située juste SOUS le plus bas (ligne vide).
                    int yBelow = Math.Min(cont.GetYByPrice(c.Low - tick, true), cont.GetYByPrice(c.Low - tick, false));
                    yBelow = Math.Max(yBelow, Math.Max(cont.GetYByPrice(c.Low, true), cont.GetYByPrice(c.Low, false)));
                    yBelow += OffsetPx;
                    // Haut de la barre = fin de la ligne située juste AU-DESSUS du plus haut.
                    int yAbove = Math.Max(cont.GetYByPrice(c.High + tick, true), cont.GetYByPrice(c.High + tick, false));
                    yAbove = Math.Min(yAbove, Math.Min(cont.GetYByPrice(c.High, true), cont.GetYByPrice(c.High, false)));
                    yAbove -= OffsetPx;

                    int xc = cont.GetXByBar(bar, true) + bw / 2;
                    int yb = yBelow, ya = yAbove;
                    const int padX = 3, padY = 1;

                    foreach (var sg in sigs)
                    {
                        string txt = ShowSign ? sg.ToString() : sg.Code + (sg.Strong ? " !" : "");
                        var sz = context.MeasureString(txt, font);
                        var col = sg.Dir > 0 ? BullColor : BearColor;
                        if (dim) col = Color.FromArgb(Math.Max(10, col.A * OutOfZoneOpacity / 100), col.R, col.G, col.B);
                        int boxW = sz.Width + 2 * padX, boxH = sz.Height + 2 * padY;
                        int bx = xc - boxW / 2;
                        int by;
                        if (BearAbove && sg.Dir < 0) { ya -= boxH; by = ya; ya -= 1; }
                        else { by = yb; yb += boxH + 1; }

                        if (ShowBackground && !dim)
                            context.FillRectangle(BackgroundColor, new System.Drawing.Rectangle(bx, by, boxW, boxH), 3);
                        context.DrawString(txt, font, col, bx + padX, by + padY);
                    }

                    // traits de stop (un par sens, signaux majeurs uniquement)
                    if (ShowStops)
                    {
                        foreach (int d in new[] { 1, -1 })
                        {
                            var maj = sigs.Where(x => x.Dir == d && x.Stop != 0 && SignalEngine.Major.Contains(x.Code)).ToList();
                            if (maj.Count == 0) continue;
                            decimal stop = d > 0 ? maj.Min(x => x.Stop) : maj.Max(x => x.Stop);   // le plus prudent
                            var col = d > 0 ? BullColor : BearColor;
                            if (dim) col = Color.FromArgb(Math.Max(10, col.A * OutOfZoneOpacity / 100), col.R, col.G, col.B);
                            int ys = (cont.GetYByPrice(stop, true) + cont.GetYByPrice(stop, false)) / 2;
                            int x1 = cont.GetXByBar(bar, true);
                            int x2 = x1 + Math.Max(bw, (int)(cont.BarsWidth + cont.BarSpacing) * StopLineBars);
                            context.FillRectangle(col, new System.Drawing.Rectangle(x1, ys - 1, Math.Max(1, x2 - x1), 2));
                            if (ShowStopTicks)
                            {
                                int tks = (int)Math.Round(Math.Abs(c.Close - stop) / tick);
                                var sf = FontFor(Math.Max(7, size - 2));
                                context.DrawString($"SL {tks}t", sf, col, x2 + 2, ys - context.MeasureString("SL", sf).Height / 2);
                            }
                        }
                    }
                }
            }

            var vfont = FontFor(8);
            string info = "Footprint Signals (Mind xtrade) " + Version
                + (ZonesActive ? (zonesActive ? $"  |  zones : {zones.Count} (hors zone : {OutOfZone})" : "  |  zones : aucune") : "")
                + (ConfluenceActive ? $"  |  confluence >= {ConfluenceMinimum}" + (ConfluenceNeedMajor ? " dont 1 majeur" : "") : "");
            context.DrawString(info, vfont, Color.FromArgb(150, 128, 128, 128), 4, Math.Max(0, context.ClipBounds.Bottom - 18));
        }
    }
}
