// Footprint Signals — moteur de détection (indépendant d'ATAS, testable seul)
// Sources : letrading.fr Footprint V2 (modules 5 à 8), annexes 5 à 10, vidéos de Jo
// « 14 Comprendre ce qui provoque les retournements » (absorption) et « La transition du delta »,
// live coaching exécution & orderflow (volume séquentiel, exhaustion par le Min Delta).
using System;
using System.Collections.Generic;
using System.Linq;

namespace FootprintSignals
{
    public sealed class FpBar
    {
        public decimal Open, High, Low, Close, Delta, Volume, MaxDelta, MinDelta;
        // prix -> (Bid = ventes agressives, Ask = achats agressifs)
        public SortedDictionary<decimal, (decimal Bid, decimal Ask)> Levels = new();

        public decimal BidAt(decimal p) => Levels.TryGetValue(p, out var v) ? v.Bid : 0m;
        public decimal AskAt(decimal p) => Levels.TryGetValue(p, out var v) ? v.Ask : 0m;
        public decimal DeltaPct => Volume > 0 ? Delta / Volume * 100m : 0m;
    }

    public readonly struct Signal
    {
        public readonly string Code;
        public readonly int Dir;      // +1 implication haussière, -1 baissière
        public readonly bool NoSign;  // étiquette déjà explicite (NOBUYER, NOSELLER)
        public readonly int Offset;   // 0 = barre évaluée ; -1 = signal posé sur la barre précédente (confirmé par celle-ci)
        public readonly decimal Stop; // niveau de stop logique selon les règles de Jo (0 = aucun)
        public readonly bool Strong;  // signal fort (ex. DIV DELTA >= 1000) -> « ! »
        public Signal(string code, int dir, bool noSign = false, int offset = 0, decimal stop = 0, bool strong = false)
        { Code = code; Dir = dir; NoSign = noSign; Offset = offset; Stop = stop; Strong = strong; }
        public Signal WithStop(decimal stop) => new Signal(Code, Dir, NoSign, Offset, stop, Strong);
        public override string ToString() => (NoSign ? Code : Code + (Dir > 0 ? "+" : "-")) + (Strong ? " !" : "");
    }

    public sealed class FpSettings
    {
        // Seuil commun « delta significatif » (contrats). ES : 150-200 ; DAX : bien plus bas.
        public decimal SigDelta = 150;
        // DIV DELTA (module 7, annexe 8) — Jo affiche des DIV dès +6 / -144 : pas de seuil par défaut
        public bool DivOn = true; public decimal DivMinDelta = 250; public decimal DivStrong = 1000;
        // DIV VOLUME (module 7, annexe 9)
        public bool DivVOn = true;
        // TRANSITION DU DELTA (vidéo « La transition du delta »)
        public bool TrnOn = true; public bool TrnShowEarly = false;
        // DELTA SURGE (module 8 : barre opposée puis N deltas croissants)
        public bool SrgOn = true; public int SrgBars = 3; public bool SrgNeedOppositeStart = true;
        // VOLUME SÉQUENTIEL (live coaching : 5 croissances consécutives du delta)
        public bool VseqOn = false; public int VseqCount = 5;
        // ABSORPTION (vidéo 14 : delta d'un côté, pas de nouvel extrême de ce côté vs barre précédente)
        public bool AbsOn = true; public decimal AbsMinPct = 5; public decimal AbsToleranceTicks = 0;
        // NO BUYER / NO SELLER (captures vidéos : Max Delta <= 0 / Min Delta >= 0 + delta suffisant)
        public bool NbOn = true; public decimal NbMinPct = 10; public decimal NbNearZeroPct = 0;
        // DELTA TAIL (module 8)
        public bool TailOn = true; public int TailMaxTicks = 3; public decimal TailMinDelta = 50; public decimal TailRestMinDelta = 0; public bool TailNeedReverseClose = true;
        // DELTA FLIP (module 8) — hors liste de Jo
        public bool FlipOn = true; public decimal FlipNearZeroPct = 10; public decimal FlipCloseNearPct = 80; public decimal FlipMinPct = 10; public bool FlipAllowMiddleBar = true;
        // IMBALANCE de retournement (module 6)
        public bool ImbOn = true; public decimal ImbRatioPct = 300; public decimal ImbMinVolume = 150; public bool ImbPocCheck = true; public int ImbMaxLevel = 2; public bool ImbNeedNewExtreme = true;
        // DELTA REVERSAL (session 15 : « le plus puissant des signaux »)
        public bool RevOn = true; public int RevBars = 1;
        // FADING MOMENTUM (narration-exécution : 284 / 246 / 26)
        public bool FadeOn = true; public decimal FadeEndPct = 50;
        // STACK IMBALANCE (module 6)
        public bool StkOn = true; public int StkMinCount = 3;
    }

    public static class Zones
    {
        // « 6815.25 ; 6830-6834 ; 6850/6852 » -> liste de (bas, haut). Virgule décimale acceptée.
        public static List<(decimal Lo, decimal Hi)> Parse(string txt)
        {
            var res = new List<(decimal, decimal)>();
            if (string.IsNullOrWhiteSpace(txt)) return res;
            foreach (var part in txt.Split(new[] { ';', '|', '\n', '\r', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var bits = part.Replace(',', '.').Split(new[] { '-', '/' }, StringSplitOptions.RemoveEmptyEntries);
                var nums = new List<decimal>();
                foreach (var b in bits)
                    if (decimal.TryParse(b.Trim(), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out var v)) nums.Add(v);
                if (nums.Count == 1) res.Add((nums[0], nums[0]));
                else if (nums.Count >= 2) res.Add((Math.Min(nums[0], nums[1]), Math.Max(nums[0], nums[1])));
            }
            return res;
        }
        public static bool Touches(decimal barLow, decimal barHigh, List<(decimal Lo, decimal Hi)> zones, decimal tol)
        {
            foreach (var z in zones)
                if (barHigh >= z.Lo - tol && barLow <= z.Hi + tol) return true;
            return false;
        }
    }

    public static class SignalEngine
    {
        // Signaux « majeurs » : patterns de Jo qui suffisent à eux seuls. Les autres ne font que renforcer.
        public static readonly HashSet<string> Major = new() { "TRANS PLUS", "FLIP", "ABS", "NOBUYER", "NOSELLER", "TAIL", "SURGE", "REVERSAL" };

        public static List<Signal> Evaluate(Func<int, FpBar> bars, int b, FpSettings s, decimal tick)
        {
            var res = new List<Signal>();
            if (b < 0) return res;
            var cur = bars(b);
            if (cur == null) return res;
            var prev = b >= 1 ? bars(b - 1) : null;

            if (s.AbsOn && prev != null) Abs(prev, cur, s, tick, res);
            if (s.TrnOn) Trn(bars, b, s, res);
            if (s.DivOn && prev != null) Div(cur, prev, s, res);
            if (s.DivVOn && prev != null) DivV(cur, prev, res);
            if (s.NbOn) Nb(cur, s, res);
            if (s.SrgOn) Srg(bars, b, s, res);
            if (s.VseqOn) Vseq(bars, b, s, res);
            if (s.TailOn) Tail(cur, prev, s, tick, res);
            if (s.FlipOn && prev != null) Flip(bars, b, s, res);
            if (s.ImbOn) Imb(cur, prev, s, tick, res);
            if (s.StkOn) Stk(cur, s, tick, res);
            if (s.RevOn) Rev(bars, b, s, res);
            if (s.FadeOn) Fade(bars, b, s, res);

            // Stop logique (règles de Jo : 1 tick au-delà de la structure du signal, jamais 2)
            for (int i = 0; i < res.Count; i++)
            {
                var x = res[i];
                var sb = x.Offset == -1 ? prev : cur;                 // barre qui porte le signal
                if (x.Code == "TRANS PLUS" && prev != null) sb = prev; // transition : sous le zéro de la bougie centrale
                if (sb == null) continue;
                res[i] = x.WithStop(x.Dir > 0 ? sb.Low - tick : sb.High + tick);
            }
            return res;
        }

        // ---------- DELTA REVERSAL ----------
        // Session 15, 23:37 : « un gros delta qui enveloppe tout le delta de la bougie précédente en cassant directement
        // le plus haut » ; « j'aime bien que ça avale les deux dernières bougies, il n'y a pas de concession ».
        static void Rev(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            var c = bars(b); var p = b >= 1 ? bars(b - 1) : null; if (c == null || p == null) return;
            int n = Math.Max(1, s.RevBars);
            for (int dir = -1; dir <= 1; dir += 2)
            {
                decimal d = c.Delta * dir;
                if (d < s.SigDelta || p.Delta * dir >= 0) continue;            // barre précédente dans l'autre camp
                decimal opp = 0; bool ok = true;
                for (int k = 1; k <= n; k++)
                {
                    var x = b - k >= 0 ? bars(b - k) : null; if (x == null) { ok = false; break; }
                    if (x.Delta * dir < 0) opp += -x.Delta * dir;
                }
                if (!ok || d < opp) continue;                                   // avale le delta opposé
                bool breaks = dir > 0 ? c.High > p.High : c.Low < p.Low;        // casse le niveau de la bougie précédente
                if (breaks) r.Add(new Signal("REVERSAL", dir));
            }
        }

        // ---------- FADING MOMENTUM ----------
        // « Delta positif qui s'épuise sur trois barres : 284, 246, 26 » -> retournement baissier (et l'inverse).
        // Seulement dans le sens de la narration : signal mineur.
        static void Fade(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            if (b < 2) return;
            var a = bars(b - 2); var m = bars(b - 1); var c = bars(b); if (a == null || m == null || c == null) return;
            for (int side = -1; side <= 1; side += 2)   // side = camp qui s'épuise
            {
                decimal d0 = a.Delta * side, d1 = m.Delta * side, d2 = c.Delta * side;
                if (d0 >= s.SigDelta && d0 > d1 && d1 > d2 && d2 > 0 && d2 <= d0 * s.FadeEndPct / 100m)
                    r.Add(new Signal("FADING", -side));
            }
        }

        // ---------- ABSORPTION ----------
        // Barre « a » (agression) confirmée par la barre suivante « n » :
        // ABS+ (sell absp) : delta de a fortement négatif, et n ne refait PAS de plus bas que a -> vendeurs absorbés.
        // ABS- (ABS DES HA) : delta de a fortement positif, et n ne refait PAS de plus haut que a -> acheteurs absorbés.
        // Validé sur 10 barres des captures de Jo (vidéos absorption, transition, flip). Étiquette posée sur « a ».
        static void Abs(FpBar a, FpBar n, FpSettings s, decimal tick, List<Signal> r)
        {
            decimal tol = s.AbsToleranceTicks * tick;
            decimal pct = Math.Abs(a.DeltaPct);
            if (a.Delta < 0 && -a.Delta >= s.SigDelta && pct >= s.AbsMinPct && n.Low >= a.Low - tol)
                r.Add(new Signal("ABS", +1, false, -1));
            if (a.Delta > 0 && a.Delta >= s.SigDelta && pct >= s.AbsMinPct && n.High <= a.High + tol)
                r.Add(new Signal("ABS", -1, false, -1));
        }

        // ---------- TRANSITION DU DELTA ----------
        // Vendeuse (vidéo) : réf +181 | barre 1 +45 (positive mais s'essouffle) | barre 2 -78 (bascule) | barre 3 -144 (confirme, plus fort)
        // TRANS = alerte sur la barre 2 ; TRANS PLUS = confirmation sur la barre 3 (|delta| >= TrnMinConfirm).
        static void Trn(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            for (int dir = -1; dir <= 1; dir += 2)   // dir = sens du retournement
            {
                if (s.TrnShowEarly && TrnEarlyAt(bars, b, dir)) r.Add(new Signal("TRANS", dir));
                if (TrnEarlyAt(bars, b - 1, dir))
                {
                    var c = bars(b); var m = bars(b - 1);
                    if (c != null && m != null)
                    {
                        decimal d3 = c.Delta * dir, d2 = m.Delta * dir;
                        if (d3 > d2 && d3 >= s.SigDelta) r.Add(new Signal("TRANS PLUS", dir));
                    }
                }
            }
        }
        // Barre b = barre 2 (bascule). Barre b-1 = barre 1 (même camp que la réf, mais plus faible). Barre b-2 = référence.
        static bool TrnEarlyAt(Func<int, FpBar> bars, int b, int dir)
        {
            if (b < 2) return false;
            var r0 = bars(b - 2); var b1 = bars(b - 1); var b2 = bars(b);
            if (r0 == null || b1 == null || b2 == null) return false;
            decimal d0 = -r0.Delta * dir, d1 = -b1.Delta * dir, d2 = b2.Delta * dir; // d0,d1 dans le sens de l'ancien camp
            return d0 > 0 && d1 > 0 && d1 < d0 && d2 > 0;
        }

        // ---------- DIV DELTA ----------
        static void Div(FpBar c, FpBar p, FpSettings s, List<Signal> r)
        {
            decimal ad = Math.Abs(c.Delta); bool strong = s.DivStrong > 0 && ad >= s.DivStrong;
            if (c.Low < p.Low && c.Delta > 0 && ad >= s.DivMinDelta) r.Add(new Signal("DIV DELTA", +1, false, 0, 0, strong));
            if (c.High > p.High && c.Delta < 0 && ad >= s.DivMinDelta) r.Add(new Signal("DIV DELTA", -1, false, 0, 0, strong));
        }

        // ---------- DIV VOLUME ----------
        static void DivV(FpBar c, FpBar p, List<Signal> r)
        {
            if (c.Low < p.Low && c.Volume > p.Volume) r.Add(new Signal("DIV VOL", +1));
            if (c.High > p.High && c.Volume < p.Volume) r.Add(new Signal("DIV VOL", -1));
        }

        // ---------- NO BUYER / NO SELLER ----------
        static void Nb(FpBar c, FpSettings s, List<Signal> r)
        {
            decimal pct = Math.Abs(c.DeltaPct);
            if (c.Delta < 0 && c.MaxDelta <= -c.Delta * s.NbNearZeroPct / 100m && -c.Delta >= s.SigDelta && pct >= s.NbMinPct) r.Add(new Signal("NOBUYER", -1, true));
            if (c.Delta > 0 && -c.MinDelta <= c.Delta * s.NbNearZeroPct / 100m && c.Delta >= s.SigDelta && pct >= s.NbMinPct) r.Add(new Signal("NOSELLER", +1, true));
        }

        // ---------- DELTA SURGE ----------
        static void Srg(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            for (int dir = -1; dir <= 1; dir += 2)
                if (SurgeAt(bars, b, s, dir) && !(!s.SrgNeedOppositeStart && SurgeAt(bars, b - 1, s, dir)))
                    r.Add(new Signal("SURGE", dir));
        }
        static bool SurgeAt(Func<int, FpBar> bars, int b, FpSettings s, int dir)
        {
            int n = Math.Max(2, s.SrgBars);
            int first = b - n + 1;
            if (first < 0 || (s.SrgNeedOppositeStart && first - 1 < 0)) return false;
            decimal prev = 0;
            for (int i = first; i <= b; i++)
            {
                var x = bars(i); if (x == null) return false;
                decimal d = x.Delta * dir;
                if (d <= 0) return false;
                if (i > first && d <= prev) return false;
                prev = d;
            }
            if (prev < s.SigDelta) return false;
            if (s.SrgNeedOppositeStart)
            {
                var st = bars(first - 1); if (st == null || st.Delta * dir >= 0) return false;
            }
            return true;
        }

        // ---------- VOLUME SÉQUENTIEL ----------
        // 5 croissances consécutives du delta (ex. 0 -> 26 -> 43 -> 103 -> ...). Signalé une fois, quand la série atteint N.
        static void Vseq(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            int n = Math.Max(2, s.VseqCount);
            for (int dir = -1; dir <= 1; dir += 2)
                if (RunLen(bars, b, dir) == n) r.Add(new Signal("VOL SEQ", dir));
        }
        // nombre de croissances consécutives se terminant en b (delta orienté dir, dernier delta > 0)
        static int RunLen(Func<int, FpBar> bars, int b, int dir)
        {
            var c = bars(b); if (c == null || c.Delta * dir <= 0) return 0;
            int k = 0;
            for (int i = b; i >= 1; i--)
            {
                var x = bars(i); var y = bars(i - 1);
                if (x == null || y == null) break;
                if (x.Delta * dir > y.Delta * dir) k++; else break;
                if (k > 50) break;
            }
            return k;
        }

        // ---------- DELTA TAIL ----------
        // Vidéo de Jo « Delta Tails » 1:32 : tail acheteur = un ou plusieurs deltas négatifs successifs
        // en queue de barre (en bas), le reste de la barre présentant un delta positif, et le prix remonte.
        // Tail vendeur (2:07, 2:41) = deltas positifs au sommet d'une barre descendante, reste négatif, clôture négative.
        // Delta d'un niveau = Ask - Bid au même prix.
        static void Tail(FpBar c, FpBar p, FpSettings s, decimal tick, List<Signal> r)
        {
            if (tick <= 0 || c.High <= c.Low) return;
            int maxK = Math.Max(1, s.TailMaxTicks);

            // Tail acheteur : deltas négatifs successifs depuis le plus bas
            decimal sum = 0; int k = 0;
            for (var pr = c.Low; pr <= c.High && k < maxK; pr += tick)
            {
                decimal d = c.AskAt(pr) - c.BidAt(pr);
                if (d < 0) { sum += d; k++; } else break;
            }
            decimal rest = c.Delta - sum;
            if (k >= 1 && pr_lt(c, k, tick) && -sum >= s.TailMinDelta && rest > 0 && rest >= s.TailRestMinDelta
                && (!s.TailNeedReverseClose || c.Close > c.Open))
                r.Add(new Signal("TAIL", +1));

            // Tail vendeur : deltas positifs successifs depuis le plus haut
            sum = 0; k = 0;
            for (var pr = c.High; pr >= c.Low && k < maxK; pr -= tick)
            {
                decimal d = c.AskAt(pr) - c.BidAt(pr);
                if (d > 0) { sum += d; k++; } else break;
            }
            rest = c.Delta - sum;
            if (k >= 1 && pr_lt(c, k, tick) && sum >= s.TailMinDelta && rest < 0 && -rest >= s.TailRestMinDelta
                && (!s.TailNeedReverseClose || c.Close < c.Open))
                r.Add(new Signal("TAIL", -1));
        }
        // la queue ne doit pas couvrir toute la barre
        static bool pr_lt(FpBar c, int k, decimal tick) => (c.High - c.Low) / tick + 1 > k;

        // ---------- DELTA FLIP ----------
        // Vidéo de Jo « Delta Flip » 1:08 : barre A avec Max Delta à 0 (ou proche) qui clôture près de son Min Delta ;
        // barre B (suivante, ou après une barre intermédiaire) avec Min Delta à 0 ou positif qui clôture près de son Max Delta.
        // Exemple : -223 (Max -1, Min -262) / -87 / +222 (Min +5, Max 238) -> FLIP+.
        static void Flip(Func<int, FpBar> bars, int b, FpSettings s, List<Signal> r)
        {
            var c = bars(b); if (c == null) return;
            for (int dir = -1; dir <= 1; dir += 2)
            {
                if (!FlipSide(c, dir, s)) continue;              // barre B dans le sens dir
                var p = b >= 1 ? bars(b - 1) : null;
                var pp = b >= 2 ? bars(b - 2) : null;
                bool direct = p != null && FlipSide(p, -dir, s);
                bool viaMid = s.FlipAllowMiddleBar && pp != null && FlipSide(pp, -dir, s) && !(p != null && FlipSide(p, dir, s));
                if (direct || viaMid) r.Add(new Signal("FLIP", dir));
            }
        }
        // Barre « toute d'un camp » : dir +1 = acheteurs seuls (Min Delta ~ 0 ou positif, clôture près du Max Delta)
        static bool FlipSide(FpBar x, int dir, FpSettings s)
        {
            decimal d = x.Delta * dir;
            if (d <= 0 || d < s.SigDelta || Math.Abs(x.DeltaPct) < s.FlipMinPct) return false;
            decimal ext = dir > 0 ? x.MaxDelta : -x.MinDelta;      // extrême dans le sens du camp (positif)
            decimal opp = dir > 0 ? -x.MinDelta : x.MaxDelta;      // incursion de l'autre camp (>0 si l'autre a dominé)
            if (ext <= 0) return false;
            if (opp > d * s.FlipNearZeroPct / 100m) return false;  // l'autre camp n'a (presque) jamais pris la main
            return d >= ext * s.FlipCloseNearPct / 100m;           // clôture près de l'extrême de delta
        }

        // ---------- IMBALANCE (diagonale) ----------
        public static bool BuyImb(FpBar c, decimal p, FpSettings s, decimal tick)
        {
            decimal a = c.AskAt(p), bd = c.BidAt(p - tick);
            if (a < s.ImbMinVolume) return false;
            return bd <= 0 || a * 100m >= bd * s.ImbRatioPct;
        }
        public static bool SellImb(FpBar c, decimal p, FpSettings s, decimal tick)
        {
            decimal bd = c.BidAt(p), a = c.AskAt(p + tick);
            if (bd < s.ImbMinVolume) return false;
            return a <= 0 || bd * 100m >= a * s.ImbRatioPct;
        }
        static void Imb(FpBar c, FpBar p, FpSettings s, decimal tick, List<Signal> r)
        {
            int maxL = Math.Max(2, s.ImbMaxLevel);
            bool newLow = !s.ImbNeedNewExtreme || (p != null && c.Low < p.Low);
            if (newLow)
                for (int lvl = 2; lvl <= maxL; lvl++)
                {
                    var pr = c.Low + (lvl - 1) * tick; if (pr > c.High) break;
                    if (BuyImb(c, pr, s, tick) && (!s.ImbPocCheck || Poc(c) <= pr + tick)) { r.Add(new Signal("IMB", +1)); break; }
                }
            bool newHigh = !s.ImbNeedNewExtreme || (p != null && c.High > p.High);
            if (newHigh)
                for (int lvl = 2; lvl <= maxL; lvl++)
                {
                    var pr = c.High - (lvl - 1) * tick; if (pr < c.Low) break;
                    if (SellImb(c, pr, s, tick) && (!s.ImbPocCheck || Poc(c) >= pr - tick)) { r.Add(new Signal("IMB", -1)); break; }
                }
        }

        // POC de la barre (niveau au plus fort volume). « Le POC ne doit pas gêner » : pour un achat, POC au niveau
        // de l'imbalance ou en dessous (idéalement en bas de barre) ; sinon attendre le break du POC.
        public static decimal Poc(FpBar c)
        {
            decimal best = -1, price = (c.High + c.Low) / 2;
            foreach (var kv in c.Levels) { var v = kv.Value.Bid + kv.Value.Ask; if (v > best) { best = v; price = kv.Key; } }
            return price;
        }

        // ---------- STACK IMBALANCE ----------
        static void Stk(FpBar c, FpSettings s, decimal tick, List<Signal> r)
        {
            if (tick <= 0) return;
            int need = Math.Max(2, s.StkMinCount);
            int runB = 0, runS = 0; bool gotB = false, gotS = false;
            for (var pr = c.Low; pr <= c.High; pr += tick)
            {
                runB = BuyImb(c, pr, s, tick) ? runB + 1 : 0;
                runS = SellImb(c, pr, s, tick) ? runS + 1 : 0;
                if (runB >= need) gotB = true;
                if (runS >= need) gotS = true;
            }
            if (gotB) r.Add(new Signal("STK", +1));
            if (gotS) r.Add(new Signal("STK", -1));
        }
    }
}
